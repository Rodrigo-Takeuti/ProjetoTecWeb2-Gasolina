-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 20-Maio-2015 às 13:46
-- Versão do servidor: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tecweb2`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `postosgasolina`
--

CREATE TABLE IF NOT EXISTS `postosgasolina` (
`id` int(11) NOT NULL,
  `nome` text NOT NULL,
  `email` text NOT NULL,
  `senha` int(11) NOT NULL,
  `nomePosto` text NOT NULL,
  `endereco` text NOT NULL,
  `gasolina` double(2,2) NOT NULL,
  `alcool` double(2,2) NOT NULL,
  `diesel` double(2,2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `postosgasolina`
--

INSERT INTO `postosgasolina` (`id`, `nome`, `email`, `senha`, `nomePosto`, `endereco`, `gasolina`, `alcool`, `diesel`) VALUES
(1, '', '', 0, 'Auto Posto Montana Ltda', 'Rua Frei Caneca, 803 Consolação São Paulo', 3.00, 2.00, 2.60),
(2, '', '', 0, 'Posto e Estabelecimento Lavabem Ltda', 'Avenida Nove de Julho, 991 Bela Vista São Paulo', 2.89, 1.89, 0.00),
(3, '', '', 0, 'Posto Vergueiro ', 'Rua Vergueiro, 5065 Ipiranga São Paulo', 2.79, 1.79, 2.59),
(4, '', '', 0, 'Posto Largo de Pinheiros', 'Rua dos Pinheiros, 1501 Jardim das Rosas Pinheiros São Paulo', 2.89, 1.79, 0.00),
(5, '', '', 0, 'Auto Posto Marques de São Vicente Ltda', 'Avenida Marques de São Vicente, 3650 Agua Branca São Paulo', 2.89, 1.89, 2.58),
(6, '', '', 0, 'Postos Reunidos Gero Ltda', 'Rua Lavradio, 160 Barra Funda São Paulo', 2.89, 1.89, 2.39),
(7, '', '', 0, 'Auto Posto Glete I Ltda', 'Alameda Glete, 697 Campos Eliseos São Paulo', 2.74, 1.74, 0.00),
(8, '', '', 0, 'Silvia Maria Pinto Santos', 'Avenida Doutor Ricardo Jafet, 1101 Vila Santa Eulalia São Paulo', 2.79, 1.89, 1.99),
(9, '', '', 0, 'Auto Posto Amigos da Lapa Ltda', 'Rua Vespasiano, 1020 Lapa São Paulo', 2.79, 1.79, 0.00),
(10, '', '', 0, 'Centro Automotivo City Pinheiros Ltda', 'Avenida Rebouças, 2083 Pinheiros São Paulo', 2.89, 1.89, 2.09);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `postosgasolina`
--
ALTER TABLE `postosgasolina`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `postosgasolina`
--
ALTER TABLE `postosgasolina`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
